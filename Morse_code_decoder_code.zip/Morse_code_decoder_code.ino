#include <Adafruit_SSD1306.h>
#include <Adafruit_GFX.h>
#include <Adafruit_BusIO_Register.h>
const uint8_t PIN_DOT = D0;
const uint8_t PIN_DASH = D1;
const uint8_t PIN_CLEAR = D2;

const unsigned long DEBOUNCE_MS = 30;
const unsigned long LETTER_GAP_MS = 1200;
const uint8_t MAX_LEN = 4;
const size_t MAX_TEXT = 42;

CONST CHAR tree[] = "ETIANMSURWDKGOHVF?L?PJBXCYZQ??"; //this is the Morse code binary tree laid flat out//

 Adafruit_SSD1306 display(128, 64, & Wire, -1);

struct Button {
  uint8_t pin;
  bool stable;
  bool reading;
  unsigned long changed;
  
};

button bDot = {PIN_DOT, TRUE, TRUE, 0};
bUTTON BdASH = {PIN _DASH, TRUE, TRUE, 0};
button bClear = {PIN_CLEAR, TRUE, TRUE, 0};

INT NODE = 0;
UINT8_T LEN = 0;
STRING SEQ = "";
STRING TEXT = "";
unsigned long lastpress = 0;
bool dirty = true;

bool pressed(Button &b)  {
  bool r = digitalRead(b.pin);
  if (r != b.reading) {
    b.reading = r;
    b.changed = millis();
  }
  if (millis() - b.changed >= DEBOUNCE_MS && b.stable != b.reading) {
    b.stable = b.reading;
    if (!b.stable) return true;
  }
  return false;
}
void addSymbol(bool dash) {
  if (len >= MAX_LEN) return;
  node = 2 * node + (dash ? 2 : 1);
  len++;
  seq += dash ? '-' : '.';
  lastPress = millis();
  dirty = true;
}
void commitLetter() {
  if (len == 0) return;
  text += TREE[node];
  if (text.length() > MAX_TEXT) text.remove(0, text.length() - MAX_TEXT);
  node = 0;
  len = 0;
  seq = "";
  dirty = true;
}
void clearAll() {
  node = 0;
  len = 0;
  seq = "";
  text = "";
  dirty = true;
}
void draw() {
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
display.setTextSize(2);
  display.setCursor(0, 0);
  display.print(seq);
display.setTextSize(4);
display.setCursor(96, 0);
  display.print(len > 0 ? TREE[node] : ' ');
display.setTextSize(1);
  display.setCursor(0, 44);
  display.print(text.substring(0, 21));
  display.setCursor(0, 54);
  if (text.length() > 21) display.print(text.substring(21));
display.display();
}
void setup() {
  pinMode(PIN_DOT, INPUT_PULLUP);
  pinMode(PIN_DASH, INPUT_PULLUP);
  pinMode(PIN_CLEAR, INPUT_PULLUP);
  Wire.begin();
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  draw();
}
void loop() {
  if (pressed(bDot)) addSymbol(false);
  if (pressed(bDash)) addSymbol(true);
  if (pressed(bClear)) clearAll();
if (len > 0 && millis() - lastPress > LETTER_GAP_MS) commitLetter();
if (dirty) {
    dirty = false;
    draw();
}
}